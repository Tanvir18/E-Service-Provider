<?php 
	include('header.php'); 
	include('config.php'); 

?>

 <form action = '' method="post">
 <center>Host is booked between:<br/>
 <?php 
$sql = "SELECT * FROM booking WHERE host_id='$_GET[hired_host_id]' and status=1";  
$result =mysqli_query($con,$sql);
while($row=$result->fetch_assoc()){
	echo "<font color='red'>$row[from_date]</font> To <font color='red'>$row[to_date]</font><br/>";


}


 ?>
</center>
<table border="0" style="width:20%" align="center">
	
	<tr>
	            		
	</tr>					
	</table>

</form>

	<?php
if(isset($_GET["hired_host_id"])){
  

     		$host_id = $_GET['hired_host_id'];
     		
			 }


    
     if(isset($_POST['submit'])){


			 $from=$_POST['from'];
			 $to=$_POST['to'];
			 $message=$_POST['message'];
			 $cook_id=$_POST['cook_id'];
			 //echo date('Y-m-d');

			 if($from>$to){
			 	echo "From date can not be greater than to date";
			 	return;
			 }

			 if($from<date('Y-m-d')){
			 	echo "From date can not be past!";
			 	return;
			 }
			 $sql = "SELECT * FROM booking WHERE host_id='$cook_id' AND (('$from' between from_date and to_date) or  ('$to' between from_date and to_date))";  
			 //echo $sql;
             $result =mysqli_query($con,$sql);

			 if($row=$result->fetch_assoc()){
			 	echo "Sorry! Host is already booked in that date";
			 	return;
			 }
				



			 $query = "INSERT INTO booking VALUES (null,'$cook_id','$_SESSION[id]','$from','$to',0,'$message')";
			 //echo $query;	  
			$result=mysqli_query($con,$query);
			 mysqli_error($con); 
			 echo "registation success"; 

		/*	  if($result){
			  	$query="UPDATE host_user SET status='booked' WHERE id='".$host_id."'";
				$result=mysqli_query($con,$query);
				if($result)
				{
					echo "booked";
				}
			  }*/
			}
			?>



