<?php 
	include('../host/header.php'); 
	include('../a/config.php');
 
?>


	<?php



    
     if(isset($_GET['id'])){


			 $id=$_GET['id'];
			 $status=$_GET['status'];
			 
			 $sql = "SELECT * FROM booking WHERE host_id='$_SESSION[id]' AND id='$id'";  
			 //echo $sql;
             $result =mysqli_query($con,$sql);
             $cur=$result->fetch_assoc();

			


             if($status ==1){
             if($cur){
             	$from=$cur['from_date'];
             	$to=$cur['to_date'];
             	$sql = "SELECT * FROM booking WHERE host_id='$_SESSION[id]' AND status=1 AND (('$from' between from_date and to_date) or  ('$to' between from_date and to_date))";  
			// echo $sql;
             $result =mysqli_query($con,$sql);

			 if($row=$result->fetch_assoc()){
			 	echo "Sorry! You have already have a booking in that date!";
			 	return;
			 	
			 }

             }
            

             }

			 $query = "UPDATE booking SET status='$status' where id='$id' and host_id='$_SESSION[id]'";
			 //echo $query;	  
			$result=mysqli_query($con,$query);
			 mysqli_error($con); 
			 if($status==1)
				 echo '<script>alert("Booking APPROVED!"); </script>'; 
			 if($status==2)
				 echo '<script>alert("Booking REJECTED!"); </script>'; 



		
				





		/*	  if($result){
			  	$query="UPDATE host_user SET status='booked' WHERE id='".$host_id."'";
				$result=mysqli_query($con,$query);
				if($result)
				{
					echo "booked";
				}
			  }*/
			}



			           $sql = "SELECT * FROM booking WHERE host_id='$_SESSION[id]' and status=0";  
            $result =mysqli_query($con,$sql);
            while($row=$result->fetch_array()){

              echo $row['user_id']." wants to book you from $row[from_date] to $row[to_date] | </br> $row[message]</br>||";
              echo "<a href='notification.php?id=$row[id]&status=1'>ACCEPT</a> |";
               echo "<a href='notification.php?id=$row[id]&status=2'>REJECT</a><br/>";
            }

			echo "<hr/>APPROVED Booking<hr/>";
  $sql = "SELECT * FROM booking WHERE host_id='$_SESSION[id]' and status=1";  
            $result =mysqli_query($con,$sql);
            while($row=$result->fetch_array()){

              echo "User: ".$row['user_id']."  from $row[from_date] to $row[to_date]<br/>";
            }

			?>





