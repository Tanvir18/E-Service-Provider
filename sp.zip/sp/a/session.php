<?php
////////////SESSION CODE//////////
if(!isset($_SESSION['email'])){
	header("Location: index.php");
	exit;
}
////////////SESSION CODE///////////\

?>