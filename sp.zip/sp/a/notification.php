
<?php 
	include('../a/header.php'); 
	include('../a/config.php');
 
?>



<?php
////////////SESSION CODE//////////
if(!isset($_SESSION['email'])){
	header("Location: index.php");
	exit;
}
////////////SESSION CODE///////////\

?>


<?php

$sql = "SELECT * FROM booking WHERE user_id='$_SESSION[id]'";  
$result =mysqli_query($con,$sql);
while($row=$result->fetch_array()){

  echo "Booking to ".$row['host_id']." From: $row[from_date] TO $row[to_date] |";
  if($row['status']==0){
  	echo "Pending<br/>";
  }else if($row['status']==1){
  	echo "<font color='green'>Accepted</font><br/>";
  }else if($row['status']==2){
  	echo "<font color='red'>Rejected</font><br/>";
  }
}


?>
<?php 
	include('../a/footer.php'); 
	
 
?>

