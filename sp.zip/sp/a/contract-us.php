<?php
	session_start();

?>


<html><head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
        <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
        <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="http://pingendo.github.io/pingendo-bootstrap/themes/default/bootstrap.css" rel="stylesheet" type="text/css">
    </head><body>
        
        <div class="navbar navbar-default navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><span>Service Provider</span></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="">
              <a href="index.php">Home</a>
            </li>
            <li class="">
              <a href="logout.php"><?php if(isset($_SESSION['email'])){ echo "Sign Out ";} else echo "Sign In ";?><?php 
                if(isset($_SESSION['email'])) {
                  echo $_SESSION['email'];
                  
                  } 
              ?>

                
              </a>
            </li>
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Sign up <i class="fa fa-caret-down"></i></a>
              <ul class="dropdown-menu" role="menu">
                <li id="signup">
                  <a href="Signup.php">as User</a>
                </li>
                <li>
                  <a href="host_sign.php">as Host</a>
                </li>
                
              </ul>
            </li>
			<li class="active">
              <a href="contract-us.php">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
        <div class="section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <img src="image\15800292_1306265302774645_9034020863057045027_o.jpg" class="img-responsive">
                    </div>
                    <div class="col-md-6">
                        <h1>Md. Tanvir Ahmed Siddiqee</h1>
                        <h3>Programmer</h3>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo
                            ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis
                            dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies
                            nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.
                            Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In
                            enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum
                            felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus
                            elementum semper nisi.</p>
                        <div class="section">
                            <div class="container">
                                <div class="row text-center">
                                    <div class="col-xs-1 text-center">
                                        <a><i class="fa fa-5x fa-fw fa-instagram"></i></a>
                                    </div>
                                    <div class="col-xs-1">
                                        <a><i class="fa fa-5x fa-fw fa-twitter"></i></a>
                                    </div>
                                    <div class="col-xs-1">
                                        <a href="https://www.facebook.com/tanvir.ahmed.545"><i class="fa fa-5x fa-fw fa-facebook"></i></a>
                                    </div>
                                    <div class="col-xs-1 text-center">
                                        <a><i class="fa fa-5x fa-fw fa-github"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h1>Athar Sadique Khan</h1>
                        <h3>Programmer</h3>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo
                            ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis
                            dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies
                            nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.
                            Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In
                            enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum
                            felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus
                            elementum semper nisi.</p>
                        <div class="section">
                            <div class="container">
                                <div class="row text-center">
                                    <div class="col-xs-1 text-center">
                                        <a><i class="fa fa-5x fa-fw fa-instagram"></i></a>
                                    </div>
                                    <div class="col-xs-1">
                                        <a><i class="fa fa-5x fa-fw fa-twitter"></i></a>
                                    </div>
                                    <div class="col-xs-1">
                                        <a href="https://www.facebook.com/aadnan.khan3"><i class="fa fa-5x fa-fw fa-facebook"></i></a>
                                    </div>
                                    <div class="col-xs-1 text-center">
                                        <a><i class="fa fa-5x fa-fw fa-github"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <img src="image\12419313_1029888720417971_6612015407341783399_o.jpg" class="img-responsive">
                    </div>
                </div>
            </div>
        </div><div class="section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <img src="image\13619810_545762728959425_1981193941566395828_n.jpg" class="img-responsive">
                    </div>
                    <div class="col-md-6">
                        <h1>Farhan Tahmid Sabit</h1>
                        <h3>Programmer</h3>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo
                            ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis
                            dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies
                            nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.
                            Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In
                            enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum
                            felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus
                            elementum semper nisi.</p>
                        <div class="section">
                            <div class="container">
                                <div class="row text-center">
                                    <div class="col-xs-1 text-center">
                                        <a><i class="fa fa-5x fa-fw fa-instagram"></i></a>
                                    </div>
                                    <div class="col-xs-1">
                                        <a><i class="fa fa-5x fa-fw fa-twitter"></i></a>
                                    </div>
                                    <div class="col-xs-1">
                                        <a href="https://www.facebook.com/fts009"><i class="fa fa-5x fa-fw fa-facebook"></i></a>
                                    </div>
                                    <div class="col-xs-1 text-center">
                                        <a><i class="fa fa-5x fa-fw fa-github"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
            include('../a/footer.php');
        ?>