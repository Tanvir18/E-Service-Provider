<div>












</div>
                <a href="#">
              </a>
              </div>
              <a href="#">
            </a>
            </div>
            <a href="#">
          </a>
          </div>
          <a href="#">
        </a>
        </div>
        <a href="#">
      </a>
      </div>
      <a href="#">
    </a>
    </div>
    <a href="#">
    </a>
    <footer class="section section-primary">
      <a href="#">
      </a>
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <h1>Service Provider</h1>
            <p>service Provider is an e-commerce web site where you can hire man power
              according to your needs who are willingly to work for you.</p>
          </div>
          <div class="col-sm-6">
            <a href="#">
            <p class="text-info text-right">
              <br>
              <br>
            </p>
            </a>
            <div class="row">
              <a href="#">
              </a>
              <div class="col-md-12 hidden-lg hidden-md hidden-sm text-left">
                <a href="#">
                </a>
                <a href="#"><i class="fa fa-3x fa-fw fa-instagram text-inverse"></i></a>
                <a href="#"><i class="fa fa-3x fa-fw fa-twitter text-inverse"></i></a>
                <a href="#"><i class="fa fa-3x fa-fw fa-facebook text-inverse"></i></a>
                <a href="#"><i class="fa fa-3x fa-fw fa-github text-inverse"></i></a>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 hidden-xs text-right">
                <a href="#"><i class="fa fa-3x fa-fw fa-instagram text-inverse"></i></a>
                <a href="#"><i class="fa fa-3x fa-fw fa-twitter text-inverse"></i></a>
                <a href="https://www.facebook.com/tanvir.ahmed.545"><i class="fa fa-3x fa-fw fa-facebook text-inverse"></i></a>
                <a href="#"><i class="fa fa-3x fa-fw fa-github text-inverse"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>