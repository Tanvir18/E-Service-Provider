

<html>
<head>
<title>registration</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap 101 Template</title>
  
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet"><!--[FONT AWESOME]-->
    <link href="css/responsive.css" rel="stylesheet">
</head>
<body>




 <?php
    include('config.php');
  
  
  ?>







  
  <?php
     
     if(isset($_POST['login'])){
		 try{
			 
			 $email=$_POST['email'];
			 $password=$_POST['password'];
			 
			 
			 if(empty($email))
			 {
			   throw new Exception ("User Name error:user name field cann't be empty <br/>")	; 
			 }
			 
			 if(empty($password))
			 {
			   throw new Exception ("Password error:password field cann't be empty <br/>")	; 
			 }
			
			 
			 	 $sql = "SELECT * FROM host_user WHERE email='$email' AND password='$password'";  
                 $host =mysqli_query($con,$sql);
                 if($hr=$host->fetch_assoc()){

				 session_start();
				 $_SESSION['email']=$email;
				 $_SESSION['id']=$hr['id'];
				 header('location:../host/index.php');
				 return;


             }

			 $sql = "SELECT * FROM user WHERE email='$email' AND password='$password'";  
             $result =mysqli_query($con,$sql);

			 if($row=$result->fetch_assoc()){

				 
				 $_SESSION['email']=$email;
				 $_SESSION['id']=$row['id'];
				 header('location:index.php');
				 return;
			 }
				 
				 



				 
				 $sql = "SELECT * FROM admin WHERE username='$email' AND password='$password'";  
                 $result =mysqli_query($con,$sql);

			     if($row=$result->fetch_assoc()){
				    
					 $_SESSION['email']="admin";
					 
					 header('location:../admin/index.php');
					 return;
					 }
				 
				 throw new Exception ("invalid user email or password")	; 
				 
				 
			 

			 }
		 
		 catch(Exception $e){
			
			$error_message=$e->getMessage();
		 }
		}
	 
   ?>
   
   
   <?php
		if(isset($error_message))
		{
			
			echo '<script language="javascript">';
			echo 'alert("'. $error_message.'")';
			echo '</script>';
			
		}

 ?>
  
  
  
  
  <div class="container">
     <div class="row ">
	    <div class="col-md-offset-4 col-sm-offset-4  ">
		    <h2>USER-LOGIN</h2>
		   <form action="" method="POST">
		       <table>
			     
				   <tr>
				     <td>Email</td>
					  <td><input type="text" name="email"></td>
				  </tr>
				   <tr>
				     <td>Password</td>
					  <td><input type="password" name="password"></td>
				  </tr>
				
				   <tr>
					  <td ><input type="submit" value="submit" name="login"></td>
					  <td><a href="Signup.php"> Create Account</a></td>
				  </tr>
				  <li class="">
              <a href="index.php">Home</a>
            </li>
			
			
            
            
		       </table>
            </form>
		</div>
	 </div>
  </div>
</body>
</html>