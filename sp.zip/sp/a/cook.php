<?php
  include('config.php');
	session_start();

?>


<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://pingendo.github.io/pingendo-bootstrap/themes/default/bootstrap.css" rel="stylesheet" type="text/css">
  </head><body>
    <div class="navbar navbar-default navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><span>Service Provider</span></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-ex-collapse">
          <ul class="nav navbar-nav navbar-right">
            <li class="">
              <a href="index.php">Home</a>
            </li>
            <li class="">
              <a href="logout.php">Sign out <?php if(isset($_SESSION['email'])){ echo $_SESSION['email'];} ?></a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Sign up <i class="fa fa-caret-down"></i></a>
              <ul class="dropdown-menu" role="menu">
                <li id="signup">
                  <a href="Signup.php">as User</a>
                </li>
                <li>
                  <a href="host_sign.php">as Host</a>
                </li>
                
              </ul>
            </li>
            <li class="">
              <a href="notification.php">Notification</a>
            </li>


            </li>
              <li class="">
                <a href="user_profile.php">Profile</a>
              </li>


            <li class="active">
              <a href="contract-us.php">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="col-md-2">
      <div class="btn-group btn-group-lg">
        <a class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Catagory<br><span class="fa fa-caret-down"></span></a>
        <ul class="dropdown-menu" role="menu">
         <li>
            <?php

          $query = "SELECT * FROM category";

          $result1 = mysqli_query($con, $query);

          


          ?>
          
          <tr>
          <td>Category</td>
          <td>

            <?php while($row1 = mysqli_fetch_array($result1)): ;?>
            <a href="cook.php?category=<?php echo $row1[1];?>"><?php echo $row1[1];?></a>
            
            <?php endwhile;?>

            </li>
        </ul>
      </div>
    </div>


    <div class="col-md-10">
      <div class="section">
        <div class="container">
          <div class="row">

<?php

          $query = "SELECT * FROM host_user WHERE category='$_REQUEST[category]' ";
  $result_query = mysqli_query($con, $query);
   
  
      while($row = mysqli_fetch_assoc($result_query)){
      
       $cook_id = $row['id']; 
       $name=$row['name'];
       $email=$row['email'];
       $contact=$row['contact'];
       $address=$row['address'];
       $national_id  =  $row['national_id'];
       $personal_information  =  $row['personal_information'];
       $skill  =  $row['skill'];
       $experience  =$row['experience'];
       $rate  =$row['rate'];
       $fileToUpload  = $row['photo'];
       
       $category  =  $row['category']; 

?>





            <div class="col-md-3">
              <img src="image\person cook.jpg" class="img-responsive">
              <h2><?php 
               echo "<a href='cook_profile.php?cook_id={$cook_id}'> {$name} </a>";
               ?>
              </h2>
              <p><?php echo $category ?></p>
            </div>

           
            

            <a href="#">
                  </a>

                   <?php 

              }

            ?>
            
      <a href="#">
          </a>
    </div>
    </div>
    </div>
    </div>


  

</body></html>


