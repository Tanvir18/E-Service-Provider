
<?php 
	include('../a/header.php'); 
	include('../a/config.php');
	include('../a/session.php');

	if(isset($_POST['submit'])){
		$pass1=$_POST['password'];
		$pass2=$_POST['confirm_password'];
		$email=$_POST['email'];
		$contact=$_POST['contact'];
		$address=$_POST['address'];
		if($pass1!=$pass2){
			echo "Password did not match!";
		}else{
			$sql = "UPDATE user set email='$email',contact='$contact',address='$address',password='$pass1' WHERE id='$_SESSION[id]'";  
		    $result =mysqli_query($con,$sql);
		    echo "Updated successfully!";
		    header('location:../a/user_profile.php');

		}
	}
	$sql = "SELECT * FROM user WHERE id='$_SESSION[id]'";  
	
    $result =mysqli_query($con,$sql);
    $cur=$result->fetch_assoc();
            

 
?>





<body>
<div class="container">
     <div class="row ">
	    <div class="col-md-offset-4 col-sm-offset-4  ">
		    <h2>Update Profile</h2>
		   <form action="" method="POST">
		       <table>
			      
				  
				   <tr>
				     <td>Email</td>
					  <td><input type="text" name="email" value="<?php echo $_SESSION['email']; ?>"></td>
				  </tr>
				   <tr>
				     <td>Password</td>
					  <td><input type="password" name="password"></td>
				  </tr>
				   <tr>
				     <td>Confirm Password</td>
					  <td><input type="password" name="confirm_password"></td>
				  </tr>
				   <tr>
				     <td>Contact</td>
					  <td><input type="text" name="contact" value="<?php echo $cur['contact']; ?>"></td>
				  </tr>
				   <tr>
				     <td>Address</td>
					  <td><input type="text" name="address" value="<?php echo $cur['address']; ?>"></td>
				  </tr>
				 
				 
				  
				 
				  
				 
		       </table>
		       <input type="submit" value="Update" name="submit" >
					<a href="user_profile.php"> Cancel</a>
            </form>
		</div>
	 </div>
  </div>
  
<?php
  include('../a/footer.php');
?>
</body>
