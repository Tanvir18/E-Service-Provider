-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2017 at 08:26 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `service`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `role`) VALUES
(2, 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `host_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `message` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `host_id`, `user_id`, `from_date`, `to_date`, `status`, `message`) VALUES
(1, 12, 9, '2017-04-05', '2017-04-22', 1, 'hello'),
(4, 12, 9, '2017-04-23', '2017-04-25', 1, 'tf788i'),
(5, 12, 9, '2017-04-28', '2017-04-28', 1, 'r7'),
(6, 12, 9, '2017-04-29', '2017-04-30', 2, ''),
(7, 12, 9, '2017-05-01', '2017-05-01', 1, ''),
(8, 12, 9, '2017-05-03', '2017-05-09', 1, 'Hello'),
(9, 12, 12, '2017-05-02', '2017-05-02', 2, 'at 7 pm at uttara'),
(10, 14, 9, '2017-04-21', '2017-04-22', 0, 'dsdfsf'),
(11, 14, 14, '2017-04-19', '2017-04-19', 0, 'tr7uo'),
(12, 12, 9, '2017-05-10', '2017-05-10', 1, 'poiuytr'),
(13, 12, 9, '2017-07-08', '2017-07-08', 1, 'wedfui'),
(14, 13, 9, '2017-04-17', '2017-04-25', 2, 'jhj'),
(15, 13, 9, '2017-04-17', '2017-04-20', 1, ''),
(16, 13, 9, '2017-04-21', '2017-04-22', 2, 'ertyuol'),
(17, 13, 9, '2017-04-21', '2017-04-22', 2, 'jhgfd'),
(18, 13, 9, '2017-04-21', '2017-04-22', 0, ''),
(19, 12, 9, '2017-06-07', '2017-06-08', 1, 'wert'),
(20, 14, 13, '2017-04-20', '2017-04-20', 0, 'hi'),
(21, 16, 9, '2017-05-08', '2017-05-08', 2, 'jnjnnnolm'),
(22, 16, 9, '2017-05-08', '2017-05-08', 1, 'sdfcgbhnjk'),
(23, 16, 9, '2017-05-09', '2017-05-09', 1, 'at uttara');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `category` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `category`) VALUES
(1, 'Cook'),
(2, 'Photography'),
(3, 'Electrician'),
(4, 'Interior designer'),
(5, 'Tutor');

-- --------------------------------------------------------

--
-- Table structure for table `host_book`
--

CREATE TABLE `host_book` (
  `host_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_email` varchar(25) NOT NULL,
  `nod` varchar(10) NOT NULL,
  `sdate` int(10) NOT NULL,
  `month` int(10) NOT NULL,
  `year` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `host_book`
--

INSERT INTO `host_book` (`host_id`, `username`, `user_email`, `nod`, `sdate`, `month`, `year`) VALUES
(7, '', '', '', 0, 0, 0),
(10, '', '', '3', 12, 4, 2017);

-- --------------------------------------------------------

--
-- Table structure for table `host_user`
--

CREATE TABLE `host_user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `national_id` varchar(20) NOT NULL,
  `personal_information` varchar(255) NOT NULL,
  `skill` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `rate` varchar(10) NOT NULL,
  `photo` longblob NOT NULL,
  `category` varchar(55) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'free'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `host_user`
--

INSERT INTO `host_user` (`id`, `name`, `email`, `password`, `contact`, `address`, `national_id`, `personal_information`, `skill`, `experience`, `rate`, `photo`, `category`, `status`) VALUES
(1, 'qe24', '1992fac@gmail.com', '1', '2435678', 'asdfghjkl', '', '', '', '', '', '', '', 'free'),
(2, '124', '1992fac@gmail.com', '2', 'er', 'r', '', '', '', '', '', '', '', 'free'),
(3, 'sabit', 'fts@gmail.com', '2', '890', 'zxc', '', '', '', '', '', '', '', 'free'),
(4, 'saaq', 'admin@example.com', '1234', 'jfa;', 'kjjk', 'jkj', 'kjkj', 'kjkk', 'kjkj', 'kjkj', '', 'cook', 'free'),
(7, 'adnan', 'adnan@gmail.com', '1', '23456789', '3456tyghui', '123456789', 'jani na', 'kisu nai', 'jaina lav nai ', '200', 0x706572736f6e20636f6f6b2e6a7067, 'cook', 'booked'),
(11, 'gabriel', 'gab@gmail.com', '123456789', '01764691489', 'H#54, r#4, khilkhet', '43154786432597459', 'gabriel', 'mexican,italian', '2 years @ Le  Meridian', '500', 0x353142463337684768694c2e5f41435f554c3332305f53523238382c3332305f2e6a7067, 'cook', 'free'),
(12, 'lokkhon', 'lok@yahoo.com', '123456789', '01632145879', 'H#54, r#4, banani', '46587321587496532', 'lokkhon', 'Indian', '4 years @ sheraton', '450', 0x63713564616d2e7765625f2e70726573735f2e3732322e6b656570617370656374726174696f2d312d312d323430783330302e6a706567, 'cook', 'free'),
(13, 'sada', 'sada@gmail.com', '', '01555555669', 'H#54, r#4, dhanmondi', '43154786432597459', 'sada', 'wide angle', 'nil', '2000', 0x706572736f6e2070686f746f677261706865722e6a7067, 'photography', 'free'),
(14, 'imran', 'imran@gmail.com', '123456789', '01718549846', 'h#58, r#7', '459654985657235917', 'imran', 'electric circuit', '4 years', '100', 0x706572736f6e20656c65637472696369616e2e6a7067, 'electrician', 'free'),
(15, 'sabbir', 'sabbir@gmail.com', '123456789', '741852', 'jdnudn', '74185209637894', 'sabbir', 'building model', '1 year', '500', '', 'Interior designer', 'free'),
(16, 'khan', 'khan@gmail.com', '1234567890', '09876543', 'g6ygy', '12345678909876543', 'khan', 'mexican', '2 year', '800', '', 'Cook', 'free'),
(17, 'tahmid', 'tahmid@gmail.com', '123', '123456789', '34567890g7gy', '23456789876543', 'tahmid', 'english', '2 year', '5000', '', 'Tutor', 'free');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `contact`, `address`) VALUES
(6, 'Tanvir', 'sam@gmail.com', '1', '123', 'qwe'),
(7, 'Adnan', 'adnan@gmail.com', '2', '1234', 'asd'),
(8, 'sabit', 'ftsa@gmail.com', 'a', '455', 'kjh'),
(9, 'Tanvir', 'tanvir@mail.com', '123456', '000000000', 'wkeurhwerjey'),
(10, 'aa', 'admin@example.com', '1234', '1234', 'asdf'),
(12, 'kala', 'kala@gmail.com', '123', '0123456789', 'f58e5'),
(13, 'tanmoy', 'tanmoy@gmail.com', '1234567890', '1234567890', 'tft6huj');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `host_user`
--
ALTER TABLE `host_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `host_user`
--
ALTER TABLE `host_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
