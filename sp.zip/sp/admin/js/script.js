tinymce.init({ selector:'textarea' });

$(document).ready(function(){
	
	$("#checkBox").click(function(){
		
	if(this.checked){
		
		$(".allCheckBox").each(function(){
			
			
			this.checked = true;
		});
	}else{
		
		$(".allCheckBox").each(function(){
			
			this.checked = false;
		});
	}
	
});
});

