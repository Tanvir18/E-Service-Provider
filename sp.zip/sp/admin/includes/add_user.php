<?php 

if(isset($_POST["create_user"])){
	
	$username = $_POST["username"];
	$password = $_POST["password"];
	
	
	
	
	$query = "INSERT INTO admin(username, password) VALUES('{$username}', 
					'{$password}')";
					
	$user_insert = mysqli_query($connection, $query);
	
	if(!$user_insert){
		die("query failed". mysqli_error($connection)); 
		
	}
	
	echo "User created! " . "<a href='user.php'>View User</a>" ;
}

?>








<form action =" " method = "post">

	
	
	
	
	
	
		<div class = "form-group">
		<label for = "username">Username</label>
		<input type = "text" class = "form-control" name = "username" />
	</div>
	

	

	
	<div class = "form-group">
		<label for = "password">Password</label>
		<input type = "password" class = "form-control" name = "password" />
	</div>
	
	
	
	
	<input type = "submit" class = "btn btn-primary btn-lg" name = "create_user" value = "Submit" />
	
</form>


