<?php 

if(isset($_POST["add_category"])){
	
	$category = $_POST["category"];
	//$password = $_POST["password"];
	
	
	
	
	$query = "INSERT INTO category(category) VALUES('{$category}')";
					
	$user_insert = mysqli_query($connection, $query);
	
	if(!$user_insert){
		die("query failed". mysqli_error($connection)); 
		
	}
	
	echo "Category Added! " . "<a href='category.php'>View Category</a>" ;
}

?>








<form action =" " method = "post">

	
	
	
	
	
	
		<div class = "form-group">
		<label for = "category">Category Name</label>
		<input type = "text" class = "form-control" name = "category" />
	</div>
	
	
	
	
	
	<input type = "submit" class = "btn btn-primary btn-lg" name = "add_category" value = "Add Category" />
	
</form>


