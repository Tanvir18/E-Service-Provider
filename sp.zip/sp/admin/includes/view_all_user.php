<div class="table-responsive">
						<table class ="table table-bordered table-striped">
							<thead>
							<tr>
								
								<th>Username</th>
								<!--<th>Edit</th>-->
								<th>Delete</th>
							
							</tr>
							</thead>
							<tbody>
							
 <?php 
 
 $query = "SELECT * FROM user";
 $post_result = mysqli_query($connection, $query);
 
 while($row = mysqli_fetch_assoc($post_result)){
	 
	 $user_id  = $row["id"];
	 $username  = $row["name"];
	 

	
	 echo "<tr>";
	
	 echo "<td>{$username}</td>";
	
	 //echo "<td><a class = 'btn btn-info' href='user.php?source=edit_user&p_id={$user_id}'>Edit</a></td>";
	 echo "<td><a class = 'btn btn-danger' href='user.php?delete={$user_id}'>Delete</a></td>";
	
	 
	 echo "</tr>";
 }
 ?>
 
 
 
 <?php 
 
 if(isset($_GET["change_to_admin"])){
		
		$change_to_admin = $_GET["change_to_admin"];
		$query = "UPDATE users SET user_role = 'admin' WHERE user_id= {$change_to_admin}";
		$aprove_query = mysqli_query($connection, $query);
		header("Location: user.php");
	}
 
 
 
 if(isset($_GET["change_to_sub"])){
		
		$change_to_sub = $_GET["change_to_sub"];
		$query = "UPDATE users SET user_role = 'subscirber' WHERE user_id= {$change_to_sub}";
		$aprove_query = mysqli_query($connection, $query);
		header("Location: user.php");
	}
 
 
 
 
	if(isset($_GET["delete"])){
		
		$delete_user_id = $_GET["delete"];

		$query = " DELETE FROM user WHERE id= {$delete_user_id}";
		$delete_query = mysqli_query($connection, $query);
	
	if(!$delete_query){
		die("failed". mysqli_error($connection));
	}
		header("Location: user.php");
	}
	
 ?>
 
 

						</tbody>
						</table>
                      </div>
                    </div>